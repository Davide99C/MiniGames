Gioco della palla 

Comandi:

Up=palla in su
down=palla in giu
left=palla a sinistra
right=palla a destra
esc=esci del gioco

#Gioco

Il gioco consiste nel non far toccare la palla ai bordi  muovendola con le freccette...in caso il punteggio arriva a -10 il programma si termina.

Requisiti

Python (2.5 o 2.6)
Pygame (versione in base alla versione di python ex 2.5 2.6 ecc)
La pallina puo cambiare velocita in base alla potenza del computer...

Grazie

